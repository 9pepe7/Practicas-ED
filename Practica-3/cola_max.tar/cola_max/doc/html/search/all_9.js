var searchData=
[
  ['v',['v',['../classCola__max.html#aa02fac17891267235c750898d5fd1779',1,'Cola_max']]],
  ['vacia',['vacia',['../classCola__max.html#af0b18f86af91ef94d7a035f87a4dcb2b',1,'Cola_max::vacia()'],['../classCola__max.html#af0b18f86af91ef94d7a035f87a4dcb2b',1,'Cola_max::vacia()']]]
];
