var searchData=
[
  ['cola_5fmax_5fpila_2eh',['Cola_max_pila.h',['../Cola__max__pila_8h.html',1,'']]]
];
