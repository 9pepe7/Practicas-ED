var searchData=
[
  ['num_5felementos',['num_elementos',['../classCola__max.html#adb26d0a523133af1f48dca6febebf72e',1,'Cola_max::num_elementos()'],['../classCola__max.html#adb26d0a523133af1f48dca6febebf72e',1,'Cola_max::num_elementos()']]]
];
