var searchData=
[
  ['poner',['poner',['../classCola__max.html#ab30df843fc57f954c239b9daba484a73',1,'Cola_max::poner(T x)'],['../classCola__max.html#ab30df843fc57f954c239b9daba484a73',1,'Cola_max::poner(T x)']]]
];
