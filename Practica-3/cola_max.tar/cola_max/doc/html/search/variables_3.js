var searchData=
[
  ['principal',['principal',['../classCola__max.html#a4bd4162675c50253a1b718f0d6dfd67e',1,'Cola_max']]]
];
