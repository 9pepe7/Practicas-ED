var searchData=
[
  ['maxdefiniciones',['maxDefiniciones',['../classDiccionario.html#ac42d3c4a95ef6f809e1fe435bff9f110',1,'Diccionario']]],
  ['maxpal',['maxPal',['../classDiccionario.html#a14af6511f2290e739f166ec6e5daa077',1,'Diccionario']]]
];
