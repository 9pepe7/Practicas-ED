var searchData=
[
  ['operator_3c',['operator&lt;',['../classTermino.html#a2674fda8a9f8f9e40ba338953e3e94ae',1,'Termino']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../classDiccionario.html#a3d353aed1ab1b515fcf2be6172123b1e',1,'Diccionario::operator&lt;&lt;()'],['../classTermino.html#a990203f35e5916790b154a3eb6baf829',1,'Termino::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classDiccionario.html#a37fecf9dd09405cc2cc91e81bf32cab0',1,'Diccionario::operator&gt;&gt;()'],['../classTermino.html#a076140e7b0c3bcbe8182d5d201725f9f',1,'Termino::operator&gt;&gt;()']]]
];
