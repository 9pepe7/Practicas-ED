var searchData=
[
  ['setpalabra',['setPalabra',['../classTermino.html#a00c9ea9d2348f75f595f2ecf46183c4c',1,'Termino']]],
  ['sonletras',['sonletras',['../classDiccionario.html#ab090cb98843f8b8d04b1bf8fedd1003d',1,'Diccionario']]]
];
