var searchData=
[
  ['termino',['Termino',['../classTermino.html',1,'Termino'],['../classTermino.html#ac3b1425fec4d38d78c5d36cb5fe8e728',1,'Termino::Termino()'],['../classTermino.html#a3498cf6d857d134b996df869409b08ba',1,'Termino::Termino(const string &amp;pal, const vector&lt; string &gt; &amp;def)'],['../classTermino.html#afa0c243fa050bd412f216c5627deae92',1,'Termino::Termino(const Termino &amp;original)'],['../classTermino.html#a5656fe283f6e949ec67d6231f7154a3d',1,'Termino::termino()']]],
  ['termino_2eh',['Termino.h',['../Termino_8h.html',1,'']]],
  ['totaldefininiciones',['totalDefininiciones',['../classDiccionario.html#aa711922bd61fc7e9e68f2e6b4df3494c',1,'Diccionario']]]
];
