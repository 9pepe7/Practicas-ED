var searchData=
[
  ['aniadirdefinicion',['aniadirDefinicion',['../classTermino.html#af57dbcf6031918e5e2d40ea2feabb0cb',1,'Termino']]],
  ['aniadirtermino',['aniadirTermino',['../classDiccionario.html#ab4cc0b335a2e048fa2920186af2fe349',1,'Diccionario']]]
];
