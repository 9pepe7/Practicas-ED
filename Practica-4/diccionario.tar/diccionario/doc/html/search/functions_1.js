var searchData=
[
  ['begin',['begin',['../classDiccionario.html#ab270eb969d580f01b358e648a3061ac4',1,'Diccionario::begin()'],['../classDiccionario.html#a5196245f1d267b0ddb9350dfa8f33b2c',1,'Diccionario::begin() const'],['../classTermino.html#a7ff605c38c22fd1c16573ad2c2900247',1,'Termino::begin()'],['../classTermino.html#abf06215ba85528bc636f337103328345',1,'Termino::begin() const']]]
];
