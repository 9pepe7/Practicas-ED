var searchData=
[
  ['diccionario',['Diccionario',['../classDiccionario.html#aa0a2191ec706b256c35b5229cc197b15',1,'Diccionario::Diccionario()'],['../classDiccionario.html#aaafc63b2a8edd982e2872f3a0233fbdc',1,'Diccionario::Diccionario(const set&lt; Termino &gt; &amp;dic)'],['../classDiccionario.html#a85540225a53beece99543842b7077494',1,'Diccionario::Diccionario(const Diccionario &amp;original)']]]
];
