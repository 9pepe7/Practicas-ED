var searchData=
[
  ['getdefinicion',['getDefinicion',['../classTermino.html#a5176371871a5f2526d0e87b9aa03e46d',1,'Termino']]],
  ['getdefiniciones',['getDefiniciones',['../classDiccionario.html#af17ee867592abfd444004dfe99b91b19',1,'Diccionario::getDefiniciones()'],['../classTermino.html#a5db983d1f0b5be57deefd0d7bfdb0cf6',1,'Termino::getDefiniciones()']]],
  ['getinicial',['getInicial',['../classTermino.html#a8f6df2737ace8436bc0d47ec8ee25a98',1,'Termino']]],
  ['getnumdef',['getNumDef',['../classTermino.html#adcc2179c9f04b22ffb1a5982c3d9b8ec',1,'Termino']]],
  ['getnumterminos',['getNumTerminos',['../classDiccionario.html#ae6d984ee1c3d6efa0748ef9708e6959c',1,'Diccionario']]],
  ['getpalabra',['getPalabra',['../classTermino.html#aca7e4f7a65e39d79ce59be80c6b88690',1,'Termino']]],
  ['getterminos',['getTerminos',['../classDiccionario.html#aec3ef2c5ffbe1166b61a36e201ed5359',1,'Diccionario']]]
];
