var searchData=
[
  ['operator_3c',['operator&lt;',['../classTermino.html#a2674fda8a9f8f9e40ba338953e3e94ae',1,'Termino']]]
];
