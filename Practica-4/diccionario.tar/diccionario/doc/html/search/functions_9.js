var searchData=
[
  ['promediodefiniciones',['promedioDefiniciones',['../classDiccionario.html#ab19e305548ad06fc274057bc17bfd68c',1,'Diccionario']]]
];
