var searchData=
[
  ['termino',['Termino',['../classTermino.html#ac3b1425fec4d38d78c5d36cb5fe8e728',1,'Termino::Termino()'],['../classTermino.html#a3498cf6d857d134b996df869409b08ba',1,'Termino::Termino(const string &amp;pal, const vector&lt; string &gt; &amp;def)'],['../classTermino.html#afa0c243fa050bd412f216c5627deae92',1,'Termino::Termino(const Termino &amp;original)']]],
  ['totaldefininiciones',['totalDefininiciones',['../classDiccionario.html#aa711922bd61fc7e9e68f2e6b4df3494c',1,'Diccionario']]]
];
